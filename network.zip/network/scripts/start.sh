#!/bin/bash
# start.sh - Brings up the orderer, 3 peers, 3 CouchDB instances, and the CLI container.
set -euo pipefail
cd "$(dirname "$0")/.."   # move to network/

if [ ! -d "crypto-config" ]; then
  echo "!! crypto-config/ not found. Run ./scripts/generate.sh first."
  exit 1
fi

echo ">> Starting the Fabric network with docker-compose..."
docker-compose -f docker-compose.yaml up -d

echo ">> Waiting for containers to settle..."
sleep 5

docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

echo ">> Network is up. Next: ./scripts/createChannel.sh"
